#include <stdio.h>

int main(void) {
    //int tomb[10] = {-43, 1, 2, -7, 4, -6, 4, -123, 65, 10};
    double tomb[10] = { 2.5, -69, 5.4, -8, -7.7, 6, 2.9, -10, -3, 9.8 };
    int negativindexek[10] = {0};

    int negativdb=0;
    for (int i=0; i < 10; i++) {
        if (tomb[i] < 0) {
            negativindexek[negativdb] = i;
            negativdb++;
        }
    }

    // - indexek
    printf("Ebbol %d szam negativ.\nIndexeik: ", negativdb);
    for (int i = 0; i < negativdb; i++)
        printf("%d ", negativindexek[i]);

    printf("\nOsszesen 10 szam van.\n");
    for (int i = 0; i < 10; i++)
        printf("[%d]=%g", i, tomb[i]);
    
    // - kiir
    printf("\nEbbol %d szam negativ.\n", negativdb);
    for (int i = 0; i < negativdb; i++)
        printf("[%d]=%g ", negativindexek[i], tomb[negativindexek[i]]);

    return 0;
}
/* valaszok:
- annyi a negativ tomb elemszama mint az eredeti mert lehet h mindegyik - szam
- kell egy negativ count az indexeleshez
*/