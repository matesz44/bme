#include <stdio.h>
#include <math.h>

double kob(double);
double abszolut(double);

int main(void) {
    for(double i = -1; i < 1; i+=0.1) {
        printf("%.4f, %.4f, %.4f, %.4f\n", i, kob(i), abszolut(i), sin(i));
    }

    return 0;
}

double kob(double sz) {
    return sz*sz*sz;
}
double abszolut(double sz) {
    if(sz<0)
        return -sz;
    else
        return sz;
}