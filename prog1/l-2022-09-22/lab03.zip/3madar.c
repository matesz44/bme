#include <stdio.h>
#include <stdbool.h>
 
char lowlow(char);
bool maganhangzo_e(char);
int main(void) {
    char c;
    while (scanf("%c", &c) != EOF) {
        if (maganhangzo_e(lowlow(c))) {
            printf("%cv%c", c, lowlow(c));
        } else {
            printf("%c", c);
        }
    }
 
    return 0;
}

char lowlow(char c) {
    if (c >= 'A' && c <= 'Z') {
        c += 'a'-'A';
    }
    return c;
}
bool maganhangzo_e(char c) {
    if (c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
        return true;
    else
        return false;
}