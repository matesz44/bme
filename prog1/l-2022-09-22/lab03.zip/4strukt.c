#include <stdio.h>

typedef struct Coords {
    double x, y;
} Coords;

int main(void) {
    Coords p1 = {2.2, 1.6}, p2;
    printf("Add meg a koordinatakat(x y): ");
    scanf("%lf %lf", &p2.x, &p2.y);
    Coords p3 = {(p1.x+p2.x)/2, (p1.y+p2.y)/2};

    printf("Felezopontok: %g, %g", p3.x, p3.y);

    return 0;
}